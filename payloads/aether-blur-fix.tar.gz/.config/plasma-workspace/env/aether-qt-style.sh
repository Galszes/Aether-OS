#!/bin/sh
# Local Qt5 style engine; use the distro Kvantum package when building the ISO.
export QT_PLUGIN_PATH="$HOME/.local/opt/aether-kvantum/usr/lib/x86_64-linux-gnu/qt5/plugins${QT_PLUGIN_PATH:+:$QT_PLUGIN_PATH}"
